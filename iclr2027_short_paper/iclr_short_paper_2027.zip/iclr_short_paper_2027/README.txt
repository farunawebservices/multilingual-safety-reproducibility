Multilingual Multi-Agent Safety (ICLR 2027 Short Paper)

Contents:
- paper_short/: LaTeX source for the 8-page short paper (main text).
  - main_short.tex: top-level file that inputs all sections.
  - 00_abstract.tex … 06_conclusion.tex: main-text sections.
  - tables/: tab_scope.tex, tab_primary_effects.tex, tab_addition3_extension.tex
  - figures/: fig_primary_effects.tex (LaTeX arrangement of 4 PDFs)
  - PDF: short_paper_draft_generic.pdf (8 pages, generic two-column style)

- paper_supplement/: LaTeX source for the 4-page supplementary appendix.
  - supplement_main.tex: top-level file for the supplement.
  - 01_primary_tables.tex … 05_reproducibility.tex: appendix sections.
  - references.bib: compact bibliography (16 entries).
  - PDF: supplementary_appendix.pdf (4 pages)

To compile the short paper:
  pdflatex generic_short.tex
  (repeat once or twice for references/hyperlinks)

To compile the supplement:
  pdflatex supplement_main.tex
  bibtex supplement_main.aux
  pdflatex supplement_main.tex (twice)

For ICLR submission, wrap paper_short/main_short.tex in the official
iclr2027 style on Overleaf instead of the generic_short.tex used here.
