#!/usr/bin/env bash
set -euo pipefail

ROOT="/workspace/multilingual-multiagent-safety"
cd "$ROOT"

rm -rf /tmp/supplement_build
mkdir -p /tmp/supplement_build

pdflatex -interaction=nonstopmode \
  -output-directory=/tmp/supplement_build \
  "$ROOT/paper_supplement/supplement_main.tex"

pdflatex -interaction=nonstopmode \
  -output-directory=/tmp/supplement_build \
  "$ROOT/paper_supplement/supplement_main.tex"

bibtex /tmp/supplement_build/supplement_main.aux || true

pdflatex -interaction=nonstopmode \
  -output-directory=/tmp/supplement_build \
  "$ROOT/paper_supplement/supplement_main.tex"

pdflatex -interaction=nonstopmode \
  -output-directory=/tmp/supplement_build \
  "$ROOT/paper_supplement/supplement_main.tex"

cp /tmp/supplement_build/supplement_main.pdf "$ROOT/paper_supplement/supplementary_appendix.pdf"

echo "Built: $ROOT/paper_supplement/supplementary_appendix.pdf"
ls -lh "$ROOT/paper_supplement/supplementary_appendix.pdf"
