# ICLR 2027 Overleaf bundle

Main document: `paper_main.tex`

Supplement document: `paper_supplement/supplement_main.tex`

The Overleaf project must provide:
- `iclr2027_conference.sty`
- `iclr2027_conference.bst`

Compile the main document from the bundle root. The main paper is designed for a nine-page limit excluding references and appendix.

The four main figures are in:
`paper_artifacts/figures/`

The main tables are in:
`paper_artifacts/tables/`

The supplement uses the same repository-relative artifact structure.
